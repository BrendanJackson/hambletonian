The **\Magento\Framework\App\Filesystem** library extends **\Magento\Framework\Filesystem** by defining list of directories available in the application.
Refer directory codes from **\Magento\Framework\App\Filesystem\DirectoryList** class in **\Magento\Framework\Filesystem** operations to get access to available application directories.
