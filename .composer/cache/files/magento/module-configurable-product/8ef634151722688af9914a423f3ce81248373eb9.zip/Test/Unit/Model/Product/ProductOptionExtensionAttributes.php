<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\ConfigurableProduct\Test\Unit\Model\Product;

use Magento\Quote\Api\Data\ProductOptionExtensionInterface;

/**
 * Class ProductOptionExtensionAttributes
 */
abstract class ProductOptionExtensionAttributes implements ProductOptionExtensionInterface
{

}
