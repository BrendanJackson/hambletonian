<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

return ['some.key' => 'some.val', 'group.1' => ['fields' => ['g1.1' => ['value' => 'g1.1.val']]]];
