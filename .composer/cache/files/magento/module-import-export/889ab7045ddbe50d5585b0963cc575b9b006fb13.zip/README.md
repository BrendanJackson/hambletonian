Magento_ImportExport module provides a framework and basic functionality for importing/exporting various entities in Magento.
It can be disabled and in such case all dependent import/export functionality (products, customers, orders etc.) will be disabled in Magento.
