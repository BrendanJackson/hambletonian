<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Quote\Model\Quote\Address\RateResult;

/**
 * @api
 * @since 100.0.2
 */
class AbstractResult extends \Magento\Framework\DataObject
{
}
