<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Sales\Controller\Order;

use Magento\Sales\Controller\OrderInterface;

class Creditmemo extends \Magento\Sales\Controller\AbstractController\Creditmemo implements OrderInterface
{
}
