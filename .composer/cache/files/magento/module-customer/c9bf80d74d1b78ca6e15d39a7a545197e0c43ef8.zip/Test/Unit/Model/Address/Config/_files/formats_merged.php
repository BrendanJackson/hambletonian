<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

return [
    'format_one' => ['code' => 'format_one', 'title' => 'format_one_title'],
    'format_two' => ['code' => 'format_two', 'title' => 'format_two_title', 'escapeHtml' => 'true']
];
