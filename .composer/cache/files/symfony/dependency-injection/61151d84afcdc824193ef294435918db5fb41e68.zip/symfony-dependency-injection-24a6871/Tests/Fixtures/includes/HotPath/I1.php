<?php

namespace Symfony\Component\DependencyInjection\Tests\Fixtures\includes\HotPath;

interface I1
{
}
